import os
import glob
import argparse
import logging
import uuid
import shutil
import platform

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Default paths - use Windows-friendly paths
DEFAULT_INPUT_DIR = os.path.join(os.getcwd(), "input_videos")
DEFAULT_OUTPUT_DIR = os.path.join(os.getcwd(), "output_videos")
TEMP_DIR = os.path.join(os.getcwd(), "tmp")

def ensure_directory_exists(directory):
    """Create directory if it doesn't exist."""
    if not os.path.exists(directory):
        os.makedirs(directory)
        logger.info(f"Created directory: {directory}")

def get_video_files(input_dir):
    """Get all video files from the input directory."""
    video_extensions = ['.mp4', '.avi', '.mov', '.mkv', '.wmv', '.flv', '.webm']
    video_files = []
    
    for ext in video_extensions:
        pattern = os.path.join(input_dir, f'*{ext}')
        video_files.extend(glob.glob(pattern))
    
    logger.info(f"Found {len(video_files)} video files in {input_dir}")
    for file in video_files:
        logger.info(f"  - {os.path.basename(file)}")
    
    return video_files

def process_videos(input_dir, output_dir, caption_type='ass', options=None):
    """Process all videos in the input directory."""
    from caption_video import process_captioning
    from transcription import process_transcription
    
    ensure_directory_exists(input_dir)
    ensure_directory_exists(output_dir)
    ensure_directory_exists(TEMP_DIR)
    
    logger.info(f"Processing videos from: {input_dir}")
    logger.info(f"Output directory: {output_dir}")
    logger.info(f"Temporary directory: {TEMP_DIR}")
    
    video_files = get_video_files(input_dir)
    
    if not video_files:
        logger.warning(f"No video files found in {input_dir}")
        return
    
    # Default options with new font and smaller size
    if options is None:
        options = {
            "font_name": "KOMIKAX",  # Updated font name
            "font_size": 24,                     # Reduced font size
            "primary_color": "&H00FFFFFF",       # White text
            "outline_color": "&H00000000",       # Black outline
            "back_color": "&H80000000",          # Semi-transparent background
            "outline": 2,                        # Thicker outline
            "alignment": 2,                      # Bottom center alignment
            "margin_v": 20                       # Margin from bottom
        }
    
    for video_path in video_files:
        try:
            video_filename = os.path.basename(video_path)
            job_id = str(uuid.uuid4())[:8]  # Use shorter job IDs for readability
            logger.info(f"Processing video: {video_filename} (Job ID: {job_id})")
            
            # Generate transcript/caption file
            logger.info(f"Generating {caption_type} file for {video_filename}")
            caption_file = process_transcription(
                video_path,
                output_type=caption_type,
                max_chars=56
            )
            
            # Process captioning
            output_path = process_captioning(
                video_path,
                caption_file,  # Pass the caption file path
                caption_type,
                options,
                job_id
            )
            
            # Move the output file to the output directory with the original filename
            output_filename = os.path.splitext(video_filename)[0] + "_captioned" + os.path.splitext(video_filename)[1]
            final_output_path = os.path.join(output_dir, output_filename)
            
            # Make sure we don't try to copy a file to itself
            if os.path.abspath(output_path) != os.path.abspath(final_output_path):
                shutil.copy2(output_path, final_output_path)
                logger.info(f"Copied output to: {final_output_path}")
            
            # Clean up temporary files
            if os.path.exists(caption_file):
                os.remove(caption_file)
                logger.info(f"Removed temporary caption file: {caption_file}")
            if os.path.exists(output_path) and os.path.abspath(output_path) != os.path.abspath(final_output_path):
                os.remove(output_path)
                logger.info(f"Removed temporary output file: {output_path}")
            
            logger.info(f"Successfully processed {video_filename}. Output saved to: {final_output_path}")
            
        except Exception as e:
            logger.error(f"Error processing {video_filename}: {str(e)}")
            import traceback
            logger.error(traceback.format_exc())

def main():
    parser = argparse.ArgumentParser(description='Batch process videos with captions')
    parser.add_argument('--input_dir', type=str, default=DEFAULT_INPUT_DIR,
                        help='Directory containing input videos')
    parser.add_argument('--output_dir', type=str, default=DEFAULT_OUTPUT_DIR,
                        help='Directory to save output videos')
    parser.add_argument('--caption_type', type=str, default='ass', choices=['srt', 'vtt', 'ass'],
                        help='Type of caption file to generate')
    
    args = parser.parse_args()
    
    # Process all videos in the input directory
    process_videos(args.input_dir, args.output_dir, args.caption_type)

if __name__ == "__main__":
    main()