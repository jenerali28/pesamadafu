import os
import time
import random
from config import Config
from together import Together  # Import Together API client
from utils.prompt_engineer import PromptEngineer

class ImageGenerator:
    def __init__(self):
        self.client = Together()  # Initialize Together API client
        self.prompt_engineer = PromptEngineer()

        # Fallback descriptions in case the prompt generation fails
        self.backup_descriptions = [
            "an old man in biblical time",
            "heaven",
        ]

    def generate_image(self, original_prompt, index, max_retries=3, script_prefix=""):
        """Attempts to generate an image, retrying with new prompt variations if needed."""
        prefix = f"{script_prefix}_" if script_prefix else ""
        
        for attempt in range(max_retries):
            if attempt == 0:
                prompt = original_prompt
            else:
                # Try generating a new prompt variation via PromptEngineer
                variation = self.prompt_engineer.generate_prompt(original_prompt)
                if variation:
                    prompt = variation
                else:
                    prompt = random.choice(self.backup_descriptions)

            # Request image from Together AI
            image_data = self.request_image_from_together_api(prompt, index)
            if image_data:
                # Save the generated image
                image_path = os.path.join(Config.IMAGE_DIR, f"{prefix}frame_{index:03d}.png")
                with open(image_path, 'wb') as f:
                    f.write(image_data)
                return image_path
            else:
                print(f"❌ Failed to generate image after {max_retries} attempts.")
                continue

        print(f"❌ Failed to generate image after {max_retries} attempts.")
        return None

    def request_image_from_together_api(self, prompt, index):
        """Request image generation from Together AI using their API."""
        try:
            # Using Together AI client to generate the image
            response = self.client.images.generate(
                prompt=prompt,
                model="black-forest-labs/FLUX.1-schnell-Free",
                width=1408,
                height=768,
                steps=4,
                n=1,
                response_format="b64_json",
                stop=[]
            )
            
            # Extract base64 image data
            b64_json = response.data[0].b64_json
            image_data = self.decode_base64_image(b64_json)
            return image_data
        except Exception as e:
            print(f"Error in generating image from Together API: {e}")
            return None

    def decode_base64_image(self, b64_json):
        """Decodes the base64 image data to binary format."""
        import base64
        from io import BytesIO
        from PIL import Image

        # Decode base64 image string
        img_data = base64.b64decode(b64_json)
        image = Image.open(BytesIO(img_data))

        # Save image as a PNG file
        img_byte_array = BytesIO()
        image.save(img_byte_array, format="PNG")
        return img_byte_array.getvalue()
