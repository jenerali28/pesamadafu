import time
import requests
from config import Config

class PromptEngineer:
    def __init__(self):
        # Use NVIDIA Inference API instead of local GPT4All
        self.invoke_url = "https://integrate.api.nvidia.com/v1/chat/completions"
        self.model_name = "meta/llama-4-maverick-17b-128e-instruct"

        # Load API key from Config
        self.api_key = Config.NVIDIA_API_KEY
        if not self.api_key:
            raise ValueError("Config.NVIDIA_API_KEY must be set in config.py")

        # Rate limiting parameters
        self.last_request_time = []
        self.rate_limit = 40  # requests per minute
        self.time_window = 60  # seconds

    def _throttle(self):
        now = time.time()
        # Keep only timestamps within the current window
        self.last_request_time = [t for t in self.last_request_time if now - t < self.time_window]
        if len(self.last_request_time) >= self.rate_limit:
            sleep_time = self.time_window - (now - self.last_request_time[0])
            print(f"Rate limit hit. Sleeping for {sleep_time:.2f} seconds.")
            time.sleep(sleep_time)
            self.last_request_time.pop(0)
        self.last_request_time.append(time.time())

    def generate_prompt(self, sentence, variation=0, image_path=None):
        try:
            self._throttle()

            # Build variation suffix
            variant_phrases = [
                "",
                " from a different angle with dynamic lighting",
                " with the character in animated motion and vibrant background",
                " showing the environment in greater Pixar-style detail",
                " with a different emotional tone while maintaining Pixar aesthetics",
            ]
            variant = variant_phrases[variation % len(variant_phrases)]
            
            # Prepare the initial prompt from the template
            initial_prompt = Config.PROMPT_TEMPLATE.format(sentence=sentence)
            
            # Modify the system prompt to emphasize Pixar style
            system_prompt = "You are an expert image prompt engineer specializing in Pixar animation style. Always include 'Pixar animation style' or similar terms explicitly in your prompts."
            
            # Create enhanced user instructions to ensure style inclusion
            user_instructions = f"""
Based on this Bible script: "{sentence}"

Create a detailed prompt for a Pixar-style animated scene. Your prompt MUST:
1. Begin with "Pixar animation style:" or include the phrase "in Pixar animation style"
2. Have vibrant colors, expressive characters, and 3D animation quality
3. Be appropriate for the biblical context
4. Use the design profile provided earlier
{variant}
"""

            # Prepare payload for NVIDIA API
            payload = {
                "model": self.model_name,
                "messages": [
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": initial_prompt},
                    {"role": "user", "content": user_instructions}
                ],
                "max_tokens": 512,
                "temperature": 0.8,  # Slightly lower temperature for more consistent outputs
                "top_p": 1.0
            }
            headers = {
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json"
            }

            # Call the API
            response = requests.post(self.invoke_url, json=payload, headers=headers)
            response.raise_for_status()
            data = response.json()

            # Extract generated content
            generated = data["choices"][0]["message"]["content"].strip()
            
            # Force include "Pixar animation style" if not already present
            if "pixar" not in generated.lower() and "animation" not in generated.lower():
                generated = f"Pixar animation style: {generated}"
            
            return generated

        except Exception as e:
            print(f"Error in prompt generation: {e}")
            return None