import os
import subprocess

# Change this if you want mixed videos somewhere else:
STORAGE_PATH = os.path.abspath("output/videos")
os.makedirs(STORAGE_PATH, exist_ok=True)

# Hardcoded path to your background music
DEFAULT_BACKGROUND_MP3 = r"C:\Users\l\Desktop\ai narrator\app-20250406T211611Z-001\app\utils\background.mp3"

def get_duration(file_path: str) -> float:
    """Return the duration of a media file, in seconds."""
    cmd = [
        'ffprobe', '-v', 'error',
        '-show_entries', 'format=duration',
        '-of', 'default=noprint_wrappers=1:nokey=1',
        file_path
    ]
    result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    try:
        return float(result.stdout.strip())
    except ValueError:
        raise RuntimeError(f"Could not determine duration of {file_path}")

def process_audio_mixing(
    video_path: str,
    video_vol: int = 100,
    audio_vol: int = 30,
    output_length: str = "video",
    job_id: str = "mixed_video"
) -> str:
    """
    Mix your hardcoded background.mp3 into a rendered video.

    - video_path: path to the .mp4 you just made
    - video_vol: percent volume of original audio
    - audio_vol: percent volume of background music
    - output_length: 'video' (match video duration) or 'audio' (match music duration)
    - job_id: base name for the output file

    Returns the full path to the mixed video.
    """
    audio_path = DEFAULT_BACKGROUND_MP3

    # sanity checks
    if not os.path.isfile(video_path):
        raise FileNotFoundError(f"Video not found: {video_path}")
    if not os.path.isfile(audio_path):
        raise FileNotFoundError(f"Audio not found: {audio_path}")

    vid_dur = get_duration(video_path)
    aud_dur = get_duration(audio_path)
    final_dur = vid_dur if output_length == "video" else aud_dur

    # build the FFmpeg filtergraph
    filter_complex = (
        f"[0:a]volume={video_vol/100}[orig];"
        f"[1:a]volume={audio_vol/100}[bg];"
        "[orig][bg]amix=inputs=2:duration=first:dropout_transition=2[aout]"
    )

    output_name = f"{job_id}.mp4"
    output_path = os.path.join(STORAGE_PATH, output_name)

    cmd = [
        "ffmpeg", "-y",
        "-i", video_path,
        "-i", audio_path,
        "-filter_complex", filter_complex,
        "-map", "0:v",
        "-map", "[aout]",
        "-c:v", "copy",
        "-c:a", "aac",
        "-t", str(final_dur),
        output_path
    ]
    subprocess.run(cmd, check=True)
    return output_path