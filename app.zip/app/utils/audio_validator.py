import os
import subprocess
import asyncio
import re
from pathlib import Path
from config import Config
from utils.audio_generator import AudioGenerator

class AudioValidator:
    """Utility class for validating and fixing audio files."""
    
    @staticmethod
    def is_valid_audio(file_path):
        """Check if an audio file is valid and readable by ffmpeg."""
        if not os.path.exists(file_path):
            return False
            
        try:
            # Use ffprobe to check if the file is valid
            result = subprocess.run(
                ["ffprobe", "-v", "error", "-show_entries", 
                 "format=duration", "-of", "default=noprint_wrappers=1:nokey=1", 
                 file_path],
                capture_output=True,
                text=True,
                check=False
            )
            
            # If ffprobe succeeds and returns a duration, the file is valid
            if result.returncode == 0 and result.stdout.strip():
                try:
                    duration = float(result.stdout.strip())
                    return duration > 0
                except ValueError:
                    return False
            return False
        except Exception:
            return False
    
    @staticmethod
    async def regenerate_corrupt_audio(script_path, idx, script_prefix=""):
        """Extract the paragraph from the script and regenerate the audio."""
        print(f"Attempting to regenerate audio for {script_prefix}_audio_{idx:03d}.mp3")
        
        # Read the script file
        try:
            with open(script_path, "r", encoding='utf-8') as f:
                script = f.read()
        except Exception as e:
            print(f"Error reading script file {script_path}: {e}")
            return None
            
        # Split into paragraphs - look for double newlines
        paragraphs = [p.strip() for p in script.split('\n\n') if p.strip()]
        
        if not paragraphs:
            # If no double newlines found, try splitting by single newlines
            paragraphs = [p.strip() for p in script.split('\n') if p.strip()]
        
        if idx >= len(paragraphs):
            print(f"Error: Index {idx} is out of range. Script has {len(paragraphs)} paragraphs.")
            return None
            
        text = paragraphs[idx]
        print(f"Regenerating audio for paragraph: {text[:50]}...")
        
        # Generate new audio file
        audio_gen = AudioGenerator()
        try:
            new_audio_path = await audio_gen.generate_audio(text, idx, script_prefix)
            print(f"Successfully regenerated audio: {new_audio_path}")
            return new_audio_path
        except Exception as e:
            print(f"Error regenerating audio: {e}")
            return None

    @staticmethod
    async def validate_and_fix_audio_files(script_name, script_path=None):
        """Validate all audio files for a script and regenerate corrupt ones."""
        # Get all audio files for this script
        pattern = f"{script_name}_audio_*.mp3"
        audio_files = sorted([p for p in Path(Config.AUDIO_DIR).glob(pattern)])
        
        if not audio_files:
            print(f"No audio files found for script {script_name}")
            return False
            
        print(f"Validating {len(audio_files)} audio files for {script_name}...")
        
        corrupted_files = []
        for audio_path in audio_files:
            file_name = audio_path.name
            print(f"Checking {file_name}...")
            
            if not AudioValidator.is_valid_audio(str(audio_path)):
                print(f"⚠️ Corrupted audio detected: {file_name}")
                corrupted_files.append(audio_path)
        
        if not corrupted_files:
            print("✅ All audio files are valid!")
            return True
            
        print(f"Found {len(corrupted_files)} corrupted audio files.")
        
        if not script_path:
            scripts_dir = os.path.join(Config.BASE_DIR, "scripts")
            script_path = os.path.join(scripts_dir, f"{script_name}.txt")
            if not os.path.exists(script_path):
                print(f"❌ Script file not found at {script_path}. Cannot regenerate audio.")
                return False
        
        # Regenerate each corrupted file
        for corrupt_file in corrupted_files:
            # Extract index from filename (e.g., script_audio_005.mp3 -> 5)
            file_name = corrupt_file.name
            try:
                idx = int(file_name.split('_')[-1].split('.')[0])
                await AudioValidator.regenerate_corrupt_audio(script_path, idx, script_name)
            except Exception as e:
                print(f"Error processing {file_name}: {e}")
        
        # Verify all files again
        all_valid = True
        for audio_path in corrupted_files:
            if not AudioValidator.is_valid_audio(str(audio_path.absolute())):
                print(f"❌ Still corrupted after regeneration: {audio_path.name}")
                all_valid = False
        
        return all_valid