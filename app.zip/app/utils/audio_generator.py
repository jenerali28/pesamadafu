import edge_tts
import asyncio
import os
import re
import subprocess
from pathlib import Path
from config import Config

class AudioGenerator:
    def __init__(self):
        self.voice = "en-US-BrianMultilingualNeural"
        self.max_retries = 3          # number of retry attempts on failure
        self.retry_delay = 20          # seconds to wait between retries
        
    @staticmethod
    def split_into_paragraphs(text):
        """Split text into paragraphs based on double newlines or consecutive single newlines"""
        text = re.sub(r'\n{2,}', '[PARA]', text)
        text = re.sub(r'([.!?])\n', r'\1 ', text)
        paragraphs = text.split('[PARA]')
        return [p.strip() for p in paragraphs if p.strip()]

    @staticmethod
    def get_sentences_from_paragraph(paragraph):
        """Extract sentences from a paragraph"""
        sentences = re.findall(r'[^.!?]+[.!?](?:\s|$)', paragraph)
        return [s.strip() for s in sentences if s.strip()]

    @staticmethod
    def _is_valid_audio(file_path):
        """Check via ffprobe if audio file has non-zero duration"""
        if not os.path.exists(file_path):
            return False
        try:
            result = subprocess.run([
                "ffprobe", "-v", "error",
                "-show_entries", "format=duration",
                "-of", "default=noprint_wrappers=1:nokey=1",
                file_path
            ], capture_output=True, text=True)
            if result.returncode == 0 and result.stdout.strip():
                try:
                    duration = float(result.stdout.strip())
                    return duration > 0
                except ValueError:
                    return False
        except Exception:
            return False
        return False
    
    async def generate_audio_for_paragraph(self, paragraph, paragraph_index, script_prefix=""):
        """Generate audio for a paragraph with retries and delay"""
        prefix = f"{script_prefix}_" if script_prefix else ""
        output_path = os.path.join(Config.AUDIO_DIR, f"{prefix}para_{paragraph_index:03d}.mp3")
        
        for attempt in range(1, self.max_retries + 1):
            try:
                print(f"Generating paragraph audio (attempt {attempt}): {paragraph[:50]}...")
                communicate = edge_tts.Communicate(paragraph, voice=self.voice)
                await communicate.save(output_path)
                
                # Validate audio file
                if self._is_valid_audio(output_path):
                    sentences = self.get_sentences_from_paragraph(paragraph)
                    return output_path, len(sentences)
                else:
                    raise RuntimeError("Generated audio file is invalid or empty.")

            except Exception as e:
                print(f"Error on attempt {attempt} for paragraph {paragraph_index}: {e}")
                if attempt < self.max_retries:
                    print(f"Retrying after {self.retry_delay} seconds...")
                    await asyncio.sleep(self.retry_delay)
                else:
                    print(f"Failed to generate valid audio for paragraph {paragraph_index} after {self.max_retries} attempts.")
                    raise

    async def generate_audio_for_script(self, script_text, script_prefix=""):
        """Generate audio for all paragraphs in a script"""
        paragraphs = self.split_into_paragraphs(script_text)
        audio_paths = []
        sentence_counts = []
        
        for idx, paragraph in enumerate(paragraphs):
            audio_path, sentence_count = await self.generate_audio_for_paragraph(
                paragraph, idx, script_prefix
            )
            audio_paths.append(audio_path)
            sentence_counts.append(sentence_count)
            print(f"Generated paragraph {idx+1}/{len(paragraphs)} with {sentence_count} sentences")
        
        return audio_paths, sentence_counts, paragraphs