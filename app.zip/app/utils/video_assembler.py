from moviepy.editor import ImageClip, concatenate_videoclips, AudioFileClip, CompositeVideoClip
from moviepy.video.fx.all import fadein, fadeout
import os
import random
from config import Config

class VideoAssembler:
    @staticmethod
    def create_video_with_paragraphs(paragraph_images, audio_paths, output_name):
        """
        Create a video from paragraphs of audio and corresponding images.
        
        Args:
            paragraph_images: List of lists, where each inner list contains images for one paragraph
            audio_paths: List of audio files, one per paragraph
            output_name: Name for the output video file
        """
        if len(paragraph_images) != len(audio_paths):
            raise ValueError(f"Number of paragraphs ({len(paragraph_images)}) doesn't match number of audio files ({len(audio_paths)})")
        
        paragraph_clips = []
        
        for para_idx, (images, audio_path) in enumerate(zip(paragraph_images, audio_paths)):
            print(f"Processing paragraph {para_idx+1}/{len(audio_paths)}")
            
            if not os.path.exists(audio_path):
                raise FileNotFoundError(f"Audio not found: {audio_path}")
            
            audio = AudioFileClip(audio_path)
            para_duration = audio.duration
            
            if not images:
                raise ValueError(f"No images provided for paragraph {para_idx+1}")
            
            # Handle paragraph with multiple sentences (and thus multiple images)
            sentence_clips = []
            sentence_count = len(images)
            
            # Calculate duration for each image
            sentence_duration = para_duration / sentence_count
            
            for img_idx, img_path in enumerate(images):
                if not os.path.exists(img_path):
                    raise FileNotFoundError(f"Image not found: {img_path}")
                
                print(f"  Processing image {img_idx+1}/{len(images)}: {os.path.basename(img_path)}")
                
                # Base image clip (resize to cinematic 1920x1080)
                base_clip = (
                    ImageClip(img_path)
                    .set_duration(sentence_duration)
                    .resize((1920, 1080))
                )
                
                # Cinematic pulsing zoom effect
                def pulse(t):
                    return 1 + 0.015 * (1 - abs((t / sentence_duration) * 2 - 1))
                
                zoomed = base_clip.resize(pulse)
                
                # Add Ken Burns effect (pan or tilt) - different for each image
                direction = random.choice(['left-right', 'right-left', 'top-bottom', 'bottom-top'])
                if direction == 'left-right':
                    position_func = lambda t: (int((1 - t/sentence_duration) * 20), 'center')
                elif direction == 'right-left':
                    position_func = lambda t: (int((t/sentence_duration) * 20), 'center')
                elif direction == 'top-bottom':
                    position_func = lambda t: ('center', int((1 - t/sentence_duration) * 20))
                else:  # bottom-top
                    position_func = lambda t: ('center', int((t/sentence_duration) * 20))
                
                pan_clip = zoomed.set_position(position_func)
                
                # Add fade in/out for first/last image in paragraph
                if img_idx == 0:
                    pan_clip = fadein(pan_clip, 0.5)
                if img_idx == len(images) - 1:
                    pan_clip = fadeout(pan_clip, 0.5)
                
                sentence_clips.append(pan_clip)
            
            # Concatenate sentence clips for this paragraph
            if sentence_clips:
                para_video = concatenate_videoclips(sentence_clips, method="compose")
                
                # Set audio for the entire paragraph
                para_video = para_video.set_audio(audio)
                paragraph_clips.append(para_video)
        
        # Concatenate paragraph clips with crossfade
        if len(paragraph_clips) == 1:
            final_clip = paragraph_clips[0]
        else:
            final_clip = concatenate_videoclips(paragraph_clips, method="compose", padding=-0.5)
        
        # Output path
        os.makedirs(Config.VIDEO_DIR, exist_ok=True)
        output_path = os.path.join(Config.VIDEO_DIR, f"{output_name}.mp4")
        
        print(f"Writing video to {output_path}...")
        
        # Write video with cinematic quality settings
        final_clip.write_videofile(
            output_path,
            fps=24,
            codec="libx264",
            audio_codec="aac",
            preset="slow",  # Best quality
            threads=4,
            bitrate="12000k"  # Higher bitrate for crisp visuals
        )
        
        # Cleanup
        for clip in paragraph_clips:
            clip.close()
        final_clip.close()
        
        print(f"Video creation complete: {output_path}")
        return output_path