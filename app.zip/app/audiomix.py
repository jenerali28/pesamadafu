#!/usr/bin/env python3
# Bulk Audio Mixer
# A script to bulk add background audio to multiple videos

import os
import subprocess
from concurrent.futures import ThreadPoolExecutor, as_completed
import logging

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# CONFIGURATION - EDIT THESE PATHS
VIDEOS_DIRECTORY = "C:/Users/l/Desktop/ai narrator/app-20250406T211611Z-001/output/videos"  # Path to your videos directory
BACKGROUND_AUDIO = "C:/Users/l/Desktop/ai narrator/app-20250406T211611Z-001/app/utils/background.mp3"  # Path to your background audio file
OUTPUT_DIRECTORY = "C:/Users/l/Desktop/ai narrator/captioning/input_videos"  # Where to save the output videos

# Additional settings
VIDEO_VOLUME = 100  # Volume percentage for original video audio (0-100)
AUDIO_VOLUME = 30   # Volume percentage for background audio (0-100)
MAX_WORKERS = 4     # Number of videos to process in parallel
VIDEO_EXTENSIONS = ['.mp4', '.avi', '.mov', '.mkv', '.webm']  # Video file types to process

def get_duration(file_path):
    """Get the duration of a media file using ffprobe."""
    cmd = ['ffprobe', '-v', 'error', '-show_entries', 'format=duration', 
           '-of', 'default=noprint_wrappers=1:nokey=1', file_path]
    
    try:
        result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, check=True)
        return float(result.stdout)
    except subprocess.CalledProcessError as e:
        logger.error(f"Error getting duration for {file_path}: {e}")
        return 0

def mix_audio_with_video(video_path, audio_path, video_vol, audio_vol, output_path):
    """Mix an audio file with a video file."""
    try:
        video_duration = get_duration(video_path)
        
        # Prepare FFmpeg command
        cmd = ['ffmpeg', '-y']
        
        # Input video
        cmd.extend(['-i', video_path])
        
        # Input audio
        cmd.extend(['-i', audio_path])
        
        # Audio filter settings
        video_vol_filter = f'[0:a]volume={video_vol/100}[v]'
        audio_vol_filter = f'[1:a]volume={audio_vol/100},atrim=duration={video_duration}[a]'
        
        # Mix the audio streams if the video has audio
        has_audio = True
        audio_check_cmd = ['ffprobe', '-v', 'error', '-select_streams', 'a', '-show_entries', 
                          'stream=codec_type', '-of', 'default=noprint_wrappers=1:nokey=1', video_path]
        
        audio_check = subprocess.run(audio_check_cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        if not audio_check.stdout.strip():
            has_audio = False
            
        if has_audio:
            mix_filter = f'{video_vol_filter};{audio_vol_filter};[v][a]amix=inputs=2:duration=longest[aout]'
            cmd.extend(['-filter_complex', mix_filter])
            audio_map = '[aout]'
        else:
            cmd.extend(['-filter_complex', audio_vol_filter])
            audio_map = '[a]'
        
        # Output settings
        cmd.extend(['-map', '0:v'])  # Map video from first input
        cmd.extend(['-map', f'{audio_map}'])  # Map processed audio
        cmd.extend(['-c:v', 'copy'])  # Copy video codec
        cmd.extend(['-c:a', 'aac'])  # Always encode audio to AAC
        
        # Explicitly set output duration to match video
        cmd.extend(['-t', str(video_duration)])
        
        cmd.append(output_path)
        
        # Run FFmpeg command
        subprocess.run(cmd, check=True)
        logger.info(f"Successfully processed: {os.path.basename(video_path)} → {os.path.basename(output_path)}")
        return True
    except Exception as e:
        logger.error(f"Error processing {video_path}: {e}")
        return False

def process_single_video(video_path, audio_path, video_vol, audio_vol, output_dir):
    """Process a single video file with the given audio."""
    video_filename = os.path.basename(video_path)
    output_filename = f"mixed_{video_filename}"
    output_path = os.path.join(output_dir, output_filename)
    
    return mix_audio_with_video(video_path, audio_path, video_vol, audio_vol, output_path)

def process_directory(video_dir, audio_path, video_vol, audio_vol, output_dir, max_workers=4, video_extensions=None):
    """Process all videos in a directory with the given audio."""
    if video_extensions is None:
        video_extensions = ['.mp4', '.avi', '.mov', '.mkv', '.webm']
    
    # Create output directory if it doesn't exist
    os.makedirs(output_dir, exist_ok=True)
    
    # Get list of video files
    video_files = []
    for root, _, files in os.walk(video_dir):
        for file in files:
            if any(file.lower().endswith(ext) for ext in video_extensions):
                video_files.append(os.path.join(root, file))
    
    if not video_files:
        logger.warning(f"No video files found in {video_dir}")
        return 0
    
    logger.info(f"Found {len(video_files)} video files to process")
    
    # Process videos in parallel
    successful = 0
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {
            executor.submit(
                process_single_video, video, audio_path, video_vol, audio_vol, output_dir
            ): video for video in video_files
        }
        
        for future in as_completed(futures):
            video = futures[future]
            try:
                result = future.result()
                if result:
                    successful += 1
            except Exception as e:
                logger.error(f"Error processing {video}: {e}")
    
    logger.info(f"Successfully processed {successful} out of {len(video_files)} videos")
    return successful

def main():
    # Validate input paths
    if not os.path.exists(BACKGROUND_AUDIO):
        logger.error(f"Audio file not found: {BACKGROUND_AUDIO}")
        return 1
    
    if not os.path.exists(VIDEOS_DIRECTORY):
        logger.error(f"Videos directory not found: {VIDEOS_DIRECTORY}")
        return 1
    
    if os.path.isfile(VIDEOS_DIRECTORY):
        # Single video mode
        os.makedirs(OUTPUT_DIRECTORY, exist_ok=True)
        video_filename = os.path.basename(VIDEOS_DIRECTORY)
        output_filename = f"mixed_{video_filename}"
        output_path = os.path.join(OUTPUT_DIRECTORY, output_filename)
        
        success = mix_audio_with_video(
            VIDEOS_DIRECTORY, BACKGROUND_AUDIO, VIDEO_VOLUME, AUDIO_VOLUME, output_path
        )
        
        if success:
            logger.info(f"Successfully processed video: {VIDEOS_DIRECTORY}")
            logger.info(f"Output saved to: {output_path}")
            return 0
        else:
            logger.error(f"Failed to process video: {VIDEOS_DIRECTORY}")
            return 1
    
    elif os.path.isdir(VIDEOS_DIRECTORY):
        # Directory mode
        num_processed = process_directory(
            VIDEOS_DIRECTORY, BACKGROUND_AUDIO, VIDEO_VOLUME, AUDIO_VOLUME,
            OUTPUT_DIRECTORY, MAX_WORKERS, VIDEO_EXTENSIONS
        )
        
        if num_processed > 0:
            logger.info(f"Batch processing complete. {num_processed} videos processed.")
            logger.info(f"Output files saved to: {OUTPUT_DIRECTORY}")
            return 0
        else:
            logger.error("No videos were successfully processed.")
            return 1

if __name__ == "__main__":
    exit(main())