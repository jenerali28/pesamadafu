from dotenv import load_dotenv
import os
from pathlib import Path

load_dotenv()

class Config:
    # API Keys
    AZURE_API_KEY = os.getenv("AZURE_API_KEY")
    TOGETHER_API_KEY = os.getenv("TOGETHER_API_KEY")
    NVIDIA_API_KEY = os.getenv("NVIDIA_API_KEY")
        
    # Path Configuration
    BASE_DIR = Path(__file__).parent.parent
    OUTPUT_DIR = BASE_DIR / "output"
    IMAGE_DIR = OUTPUT_DIR / "images"
    AUDIO_DIR = OUTPUT_DIR / "audio"
    VIDEO_DIR = OUTPUT_DIR / "videos"
    LOG_DIR = BASE_DIR / "logs"
    CAPTIONS_DIR = OUTPUT_DIR / "captions"
    
    # Files
    SCRIPT_PATH = r"C:\Users\l\Desktop\ai narrator\app-20250406T211611Z-001\app\script.txt"
    LOG_FILE = LOG_DIR / "app.log"
    
    # ImageFX Path
    IMAGEFX_PATH = BASE_DIR / "imageFX-api-main"
    
    # Prompt Template - updated for Pixar animation style
    PROMPT_TEMPLATE = """Act as a prompt engineer and video director. I will provide a Bible script sentence, and you will create a single-sentence text-to-image prompt describing a scene consistent with the following Pixar animation style design profile:

Color Scheme: vibrant, cheerful colors with soft gradients and bold primary accents
Lighting & Mood: bright, warm lighting with gentle shadows and ambient occlusion
Facial Expression Style: expressive, slightly exaggerated features with emotive eyes and eyebrows
Character Design: stylized proportions with slightly larger heads, expressive eyes, and simplified features
Text Style: none (omit any typographic overlays for clean imagery)
Composition Style: dynamic, slightly angled perspectives with appealing depth of field
Visual Effects: smooth, polished surfaces with subtle reflections and soft particle effects
Emotional Tone: heartwarming, inspiring, family-friendly with moments of humor
Image Strategy: character-focused storytelling with clear emotional connection
Design Consistency: Pixar-like 3D animation quality with attention to texture and detail
General Style Tags: Pixar animation, 3D cartoon, family-friendly, emotionally resonant, stylized realism

The scene should:
- Resemble high-quality 3D Pixar animation style
- Use vibrant colors and expressive character designs
- Focus on action and environment relevant to the Bible story with costumes appropriate to biblical times
- Characters should appear stylized yet relatable, without specific identifiable names or labels
- 16:9 landscape aspect ratio

REMEMBER ONLY OUTPUT THE PROMPT AND NOTHING ELSE, DON'T EVEN SAY HERE IS THE PROMPT OR WHATSOEVER

Script sentence: {sentence}

Generated prompt:"""

    @staticmethod
    def ensure_directories_exist():
        """Create output directories if they don't exist."""
        os.makedirs(Config.IMAGE_DIR, exist_ok=True)
        os.makedirs(Config.AUDIO_DIR, exist_ok=True)
        os.makedirs(Config.VIDEO_DIR, exist_ok=True)
        os.makedirs(Config.CAPTIONS_DIR, exist_ok=True)
        os.makedirs(Config.LOG_DIR, exist_ok=True)
        
        # Create scripts directory if it doesn't exist
        scripts_dir = os.path.join(Config.BASE_DIR, "scripts")
        os.makedirs(scripts_dir, exist_ok=True)
        return scripts_dir