import os
import asyncio
import glob
import shutil
import subprocess
from pathlib import Path
from config import Config
from utils.prompt_engineer import PromptEngineer
from utils.image_generator import ImageGenerator
from utils.audio_generator import AudioGenerator
from utils.audio_validator import AudioValidator
from utils.video_assembler import VideoAssembler
from utils.audio_mixing import process_audio_mixing

def ensure_directories_exist():
    # Create necessary output directories
    os.makedirs(Config.IMAGE_DIR, exist_ok=True)
    os.makedirs(Config.AUDIO_DIR, exist_ok=True)
    os.makedirs(Config.VIDEO_DIR, exist_ok=True)
    scripts_dir = Config.BASE_DIR / 'scripts'
    os.makedirs(scripts_dir, exist_ok=True)
    return scripts_dir

async def process_script_with_paragraphs(script_path, continue_from_existing=True, cleanup_after=True):
    '''
    Process a single script: generate (or resume) audio and images, assemble video, and mix audio.
    Always skips existing valid assets when continue_from_existing is True.
    '''
    name = Path(script_path).stem
    print(f'\n=== Processing script: {name} ===')

    # Read script text
    try:
        text = Path(script_path).read_text(encoding='utf-8')
    except Exception as e:
        print(f'Error reading script {script_path}: {e}')
        return False

    ensure_directories_exist()

    # Split into paragraphs and count sentences
    paragraphs = AudioGenerator.split_into_paragraphs(text)
    sentence_counts = [len(AudioGenerator.get_sentences_from_paragraph(p)) for p in paragraphs]

    # 1. Generate or resume audio
    audio_gen = AudioGenerator()
    audio_paths = []
    for idx, paragraph in enumerate(paragraphs):
        audio_file = Config.AUDIO_DIR / f'{name}_para_{idx:03d}.mp3'
        if continue_from_existing and audio_file.exists() and is_valid_audio(str(audio_file)):
            print(f'Skipping existing audio for paragraph {idx}')
            audio_paths.append(str(audio_file))
        else:
            try:
                path, _ = await audio_gen.generate_audio_for_paragraph(paragraph, idx, name)
                audio_paths.append(path)
            except Exception as e:
                print(f'Audio generation failed at paragraph {idx}: {e}')
                return False

    # 2. Validate and regenerate corrupted audio
    for idx, path in enumerate(audio_paths):
        if not AudioValidator.is_valid_audio(path):
            print(f'Corrupted audio detected for paragraph {idx}, regenerating...')
            try:
                new_path, _ = await audio_gen.generate_audio_for_paragraph(paragraphs[idx], idx, name)
                audio_paths[idx] = new_path
            except Exception as e:
                print(f'Failed to regenerate audio for paragraph {idx}: {e}')
                return False

    # 3. Extract sentences for images
    sentences_all = []
    for p in paragraphs:
        sentences_all.extend(AudioGenerator.get_sentences_from_paragraph(p))

    # 4. Generate or resume images
    prompt_engineer = PromptEngineer()
    image_gen = ImageGenerator()
    images = []
    for idx, sent in enumerate(sentences_all):
        image_file = Config.IMAGE_DIR / f'{name}_frame_{idx:03d}.png'
        if continue_from_existing and image_file.exists():
            print(f'Skipping existing image for sentence {idx}')
            images.append(str(image_file))
        else:
            prompt = prompt_engineer.generate_prompt(sent)
            print(f'Generated prompt: {prompt}')
            img_path = image_gen.generate_image(prompt, idx, script_prefix=name)
            if img_path:
                images.append(img_path)
            else:
                print(f'Image generation failed at sentence {idx}')
                return False

    # 5. Assemble video and mix audio
    try:
        mapped = []
        i = 0
        for cnt in sentence_counts:
            group = images[i:i+cnt] or [images[-1]]
            mapped.append(group)
            i += cnt

        print('Assembling video...')
        video_path = VideoAssembler.create_video_with_paragraphs(mapped, audio_paths, f'{name}_video')

        print('Mixing background audio...')
        mixed_path = process_audio_mixing(
            video_path=video_path,
            audio_path="C:/Users/l/Desktop/ai narrator/app-20250406T211611Z-001/app/utils/background.mp3",
            video_vol=100,
            audio_vol=30,
            output_length='video',
            job_id=f'{name}_with_music'
        )
        print(f'Final mixed video: {mixed_path}')

        if cleanup_after:
            clean_up_assets(name)

        return True
    except Exception as e:
        print(f'Error during video assembly: {e}')
        return False

def is_valid_audio(file_path):
    # Check via ffprobe if an audio file is valid (non-zero duration)
    try:
        result = subprocess.run([
            'ffprobe', '-v', 'error',
            '-show_entries', 'format=duration',
            '-of', 'default=noprint_wrappers=1:nokey=1',
            file_path
        ], capture_output=True, text=True)
        if result.returncode == 0 and result.stdout.strip():
            return float(result.stdout.strip()) > 0
    except:
        pass
    return False

def clean_up_assets(name):
    # Remove generated images and audio for a completed script
    print(f'Cleaning up assets for {name}...')
    for f in glob.glob(str(Config.IMAGE_DIR / f'{name}_frame_*.png')):
        os.remove(f)
    for f in glob.glob(str(Config.AUDIO_DIR / f'{name}_para_*.mp3')):
        os.remove(f)
    print('Cleanup complete.')

def main():
    ensure_directories_exist()
    print('/nBible Narration Video Generator')
    print(f'Script folder: {Config.BASE_DIR / 'scripts'}')
    print('1. Single script/n2. All scripts/n3. Exit')
    choice = input('Choose (1-3): ')
    cleanup = input('Delete assets after? (y/n): ').lower() != 'n'

    if choice == '1':
        name = input('Script filename: ')
        path = Config.BASE_DIR / 'scripts' / name
        asyncio.run(process_script_with_paragraphs(str(path), continue_from_existing=True, cleanup_after=cleanup))
    elif choice == '2':
        for file in glob.glob(str(Config.BASE_DIR / 'scripts' / '*.txt')):
            asyncio.run(process_script_with_paragraphs(file, continue_from_existing=True, cleanup_after=cleanup))
    else:
        print('Exiting...')

if __name__ == '__main__':
    main()